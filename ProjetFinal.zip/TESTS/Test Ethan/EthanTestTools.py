# This is a sample Python script.

# Press Maj+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# Ceci est un objet
def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
print("hello")
# Importation de pyplot avec matplotlib
from matplotlib import pyplot

print(pyplot.plot([1, 2, 3, 6], [1, 4, 9, 36]))

# Creation exe:
# C:\Users\ethan\AppData\Roaming\Python\Python39\site-packages\pyinstaller.exe --onefile --windowed D:\ethan\OneDrive - Efrei\L1-S2\L1S2-PROGRAMMATION\PycharmProjects\L1S2-ProjTransv-Jeu2D\Jeu2D.py

